#!/usr/bin/env python3
"""Create only safe source fixtures from READY_KEYWORDS_ONLY recipe rows.

Usage on RHEL 9:
  python3.9 generate_ready_fixtures.py --input test_recipes.csv --output ready_source_fixtures
"""

from __future__ import annotations

import argparse
import csv
import hashlib
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate ready DG DLP source fixtures from test_recipes.csv.")
    parser.add_argument("--input", type=Path, required=True, help="Path to test_recipes.csv")
    parser.add_argument("--output", type=Path, required=True, help="New fixture output directory")
    parser.add_argument("--overwrite", action="store_true", help="Allow an existing output directory only when it is empty.")
    args = parser.parse_args()

    if not args.input.is_file():
        parser.error(f"Input CSV was not found: {args.input}")
    if args.output.exists() and any(args.output.iterdir()):
        if not args.overwrite:
            parser.error("Output directory is not empty. Use a new directory, or clear it deliberately before using --overwrite.")
    args.output.mkdir(parents=True, exist_ok=True)

    with args.input.open("r", encoding="utf-8-sig", newline="") as stream:
        recipes = list(csv.DictReader(stream))

    ready = [row for row in recipes if row.get("recipe_status", "").strip() == "READY_KEYWORDS_ONLY"]
    manifest_rows: list[dict[str, str]] = []
    for number, row in enumerate(ready, start=1):
        filename = f"fx_{number:03d}.txt"
        content = row.get("candidate_content_lines", "").rstrip("\n") + "\n"
        (args.output / filename).write_text(content, encoding="utf-8", newline="\n")
        manifest_rows.append({
            "fixture_file": filename,
            "fixture_key": row.get("fixture_key", ""),
            "policy_name": row.get("policy_name", ""),
            "detection_rule_name": row.get("rule_name", ""),
            "detection_severity": row.get("severity", ""),
            "detection_logic": row.get("rule_logic_expression", ""),
            "isolation_requirement": row.get("isolation_requirement", ""),
            "sha256": hashlib.sha256(content.encode("utf-8")).hexdigest(),
        })

    manifest = args.output / "fixture_manifest.csv"
    with manifest.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(manifest_rows[0]) if manifest_rows else ["fixture_file"])
        writer.writeheader()
        writer.writerows(manifest_rows)

    print(f"Created {len(ready)} ready source fixtures in {args.output}")
    print("No pending-review recipe was converted into a fixture.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
