# DG DLP Ready Source Fixtures

This package contains source files that can be used now for the first classification-test wave.

- `ready_source_fixtures/`: 125 UTF-8 text fixtures.
- `fixture_manifest.csv`: maps each neutral filename (`fx_001.txt`, etc.) to the Symantec policy and independent named Detection Rule.
- `fixture_review_queue.csv`: 138 named Detection Rules that must not be tested yet because their source recipe needs a regex sample, a dynamic value, or a PDF review.
- `policy_fixture_readiness.csv`: readiness summary by policy.

Each file contains only the values extracted for one independent named Detection Rule. It contains every extracted internal AND value, but it does not combine different named Detection Rules.

## First test wave

1. Open `fixture_manifest.csv` and select a row with `fixture_execution_status=Ready to execute`.
2. Use the neutral filename shown in `fixture_file`; do not rename it to a policy/rule name.
3. Upload that file through the approved GitHub or internal-portal route.
4. Verify the event in ARC/DGMC and record the result against the matching `classification_test_id` in the test-plan workbook.
5. If a different classification also matches, record it as an overlap/collision; do not change the fixture contents before recording the evidence.

Do not upload files from the review queue until the missing source value has been validated.

## Regenerate on RHEL 9

The package also includes `generate_ready_fixtures.py`. It has no pip dependencies:

```bash
python3.9 generate_ready_fixtures.py \
  --input /path/to/test_recipes.csv \
  --output /path/to/ready_source_fixtures
```

It generates fixtures only for `READY_KEYWORDS_ONLY` rows and leaves all other rows pending review.
