local google_docs_log = {}
local act = require "actions"

-- Handle incoming requests
function google_docs_log.request(req)
    local url = req.url
    if req.method == "POST" then
        if string.match(url, "/naLogImpressions$") ~= nil then
            act.ignore_request()
        end
    end
end

-- Handle response to the browser
function google_docs_log.response(resp)
end

return google_docs_log
