local google_cloud_log = {}
local act = require "actions"

-- Handle incoming requests
function google_cloud_log.request(req)
    local url = req.url
    if req.method == "POST" then
        if string.match(url, "^/log$") ~= nil then
            act.ignore_request()
        end
    end
end

-- Handle response to the browser
function google_cloud_log.response(resp)
end

return google_cloud_log