local google_meet = {}
local act = require "actions"

-- Handle incoming requests
function google_meet.request(req)
    local url = req.url
    if req.method == "POST" or req.method == "GET" then
        if string.match(url, "^/hangouts/v$") ~= nil or string.match(url, "boq%-rtc") or 
           string.match(url, "google.rtc.meetings") or
           string.match(url, "communication.rtctools") then
		    --print("Skipping Request : ",url)
			-- Ignore request and response
            act.ignore_transaction()
        end
    end
end

return google_meet