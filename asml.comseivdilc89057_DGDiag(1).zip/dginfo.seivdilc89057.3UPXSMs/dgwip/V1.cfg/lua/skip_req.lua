local skip_script = {}
local act = require "actions"

local host_keywords = {
   "telemetry",
   "collector",
   "metrics",
}

local uri_keywords = {
   "/*telemetry",
   "/*collector",
   "/metrics",
   "/log$",
   "/log/",
}

local function match_keyword(hay, keywords)
   for _, needle in ipairs(keywords) do
      if string.find(hay, needle) ~= nil then
         return needle
      end
   end
   return nil
end

function skip_script.request(req)
   local url = req.url
   local host = req.host
   if host ~= nil then
      local host_name = string.lower(host)
      local keyword = match_keyword(host_name, host_keywords)
      if keyword ~= nil then
         act.ignore_request()
         return
      end
   end
   if url ~= nil then
      local url = string.lower(url)
      local path = string.match(url, "^https?://[^/]+(/.*)") or url
      local keyword = match_keyword(path, uri_keywords)
      if keyword ~= nil then
         act.ignore_request()
         return
      end
   end
end

return skip_script
