local s3 = {}
local act = require "actions"

function s3.request(req)
   local url = req.url
   if req.method ~= "PUT" then
      if string.match(url, "^/panoramaroute$") ~= nil then
         act.ignore_request()
      end
      return
   end
   local file = req.url:match("^.+/(.+)$")
   act.file_upload(file)
end


return s3
