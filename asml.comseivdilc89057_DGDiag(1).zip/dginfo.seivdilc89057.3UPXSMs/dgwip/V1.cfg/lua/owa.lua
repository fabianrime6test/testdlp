local owa = {}
local act = require "actions"

function owa.request(req)
  local head = json_embedded_file(req, "Body.Attachments.Content", "base64")
  if head ~= nil then
    act.file_upload("POSTDATA.TXT", head)
  end
  
end


return owa
