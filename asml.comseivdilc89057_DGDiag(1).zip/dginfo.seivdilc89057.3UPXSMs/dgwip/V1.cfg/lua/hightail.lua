local hightail = {}
local act = require "actions"

local u = require "utils"
local act = require "actions"



local UPLOAD = "upload"
local ctx = nil

-- Note that hightail and opendrive use exactly the same protocol.
-- We use the same script for both
function hightail.request(req)
   ctx = nil
   local url = req.url
   if string.match(url, "/api/v1/upload/resumable") ~= nil then
      ctx = {type= UPLOAD}
   end
end

function hightail.request_part(p)
   if ctx ~= nil and ctx["type"] == UPLOAD then
      local body = p.body
      if body ~= nil then
	 
	 if body.form_name == "resumableFilename" then
	    ctx.file_name = body.form_value
	 elseif body.form_name == "file" and ctx.file_name ~= nil then
	    act.file_upload(ctx.file_name)
	 end 	 
      end
   end
end

   
return hightail
