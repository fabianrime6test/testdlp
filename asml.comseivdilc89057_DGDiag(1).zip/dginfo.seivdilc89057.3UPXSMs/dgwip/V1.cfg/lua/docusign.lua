local docusign = {}
local act = require "actions"

-- Handle incoming requests
function docusign.request(req)
   local url = req.url
   if req.method == "PUT" or req.method == "POST" then
    if string.match(url, "documents") ~= nil then
        local head = json_embedded_file(req, "documentBase64", "base64")
        if head ~= nil then
            act.file_upload("POSTDATA.TXT", head)
        end
    end
   end
end

return docusign