local netdocuments = {}
local act = require "actions"

function netdocuments.request(req)
   local url = req.url
   if req.method == "POST" and string.find(url, "/neWeb2/docUpload.aspx") ~= nil then
      local headers = req.headers
      local file = headers["X-Filename"]
      if file ~= nil then
	 act.file_upload(file)
      end
   end
end


return netdocuments
