local dropbox = {}
local act = require "actions"

-- Handle incoming requests
function dropbox.request(req)
   local url = req.url
   local query = req.query
   if string.match(url, "chunked_upload") ~= nil then
      if query["name"] ~= nil then	 
	 act.file_upload(query["name"][1])
      end
   end
end

return dropbox
