local actions = {}

function actions.file_upload(originFname, head)
   cass.set_action({
	 action="NTU",
	 origin_file=originFname,
	 head=head
   })
end

function actions.file_download(originFname)
   cass.set_action(
      {action="NTD",
       origin_file=originFname
   })
end

function actions.sendMail(draft, from, to, cc, bcc, subject, body, ishtml)
   -- go parses email addresses
   local action = {
      action="SendMail",
      from=from,
      to=to,
      cc=cc,
      bcc=bcc,
      subject=subject,
      body=body,
      ishtml=ishtml,
      draft=draft
   }
   cass.set_action(action)
end

function actions.ewsMail(soapaction)
   cass.set_action( {
      action="EwsMail",
      soap_action=soapaction
   })
end

function actions.ignore_request()
   cass.set_action( {
	 skip=true
   })
end

function actions.ignore_transaction()
   cass.set_action( {
	 skip_transaction=true
   })
end

function actions.parse_response_body()
   cass.set_action( {
	 parse_response_body=true
   })
end

return actions
