local bing_cortana = {}
local act = require "actions"

-- Handle incoming requests
function bing_cortana.request(req)
    local url = req.url
    if req.method == "POST" then
        if string.match(url, "^/threshold/xls.aspx") ~= nil then
            act.ignore_request()
        end
    end
end

-- Handle response to the browser
function bing_cortana.response(resp)
end

return bing_cortana