# ASML – Data samples para validar las reglas eDLP (bundle Linux)

## Contenido

| Elemento | Qué es |
|---|---|
| `data_samples/` | 139 archivos de prueba para 74 use cases: 124 generados desde las reglas de clasificación DG, 14 desde detection rules Symantec sin equivalente DG y 1 archivo de control |
| `ASML_DLP_TestPlan.xlsx` | Plan de pruebas: archivo × destino con la acción esperada en Symantec y en DG, más las columnas a rellenar desde ARC |
| `verify_arc.py` | Cruza el export de ARC con el plan y marca PASS / FAIL / SIN EVENTO |

## Nombre de los archivos

`<UseCase Symantec>__<regla DG o Symantec>_<acción esperada>.<ext>`

- **Sufijo:** la acción Symantec más estricta esperada en algún destino. Puede ser `_block`, `_userdecision` (User Cancel en Symantec), `_notify`, `_monitor`, `_noincident` o `_validar`. La acción exacta por destino está en el plan, porque **la acción depende del destino**: el mismo archivo da Block en public y Monitor en trusted.
- **Extensión:** la que exige la regla (`.csv`, `.m`, `.kdb`, `.dat`, `.docx`, `.gbrjob`…). Si la regla no exige ninguna, `.txt`.
- **Nombres que empiezan por un token** (`D00.`, `4022.`, `MC_event_log.`, `COATING01_dat__`, `402201-110-01.01__`…): la regla DG o Symantec se basa en el nombre o la ruta del fichero, y el token es lo que la dispara. No lo renombres.
- **`_validar`:** reglas Symantec basadas en IDM o en plantillas (Customer Surveys IDM, CSR Form). No se pueden reproducir con datos sintéticos; hacen falta documentos reales indexados.

## Cómo se generó el contenido

1. Para cada regla DG de clasificación (Core) se recorre el árbol XML de `settings.xml`: AND/OR/NOT, frecuencia de entidad con su umbral, contadores, extensión, ruta/regex y excepciones.
2. Se genera texto que cumple la rama de *source file*:
   - entidades regex con muestras que cumplen el patrón;
   - entidades de diccionario con entradas reales del EntrySet;
   - BSN holandés con prueba del 11, RRN coreano con dígito de control y tarjetas con Luhn.
3. Un evaluador independiente reevalúa el fichero final contra **todas** las reglas de clasificación DG, para obtener los tags reales que produciría.
4. El contenido se evalúa también contra las detection rules Symantec (keywords con mínimo, whole-word, proximidad, regex y nombre de fichero). Si no coincidía, se amplió con las keywords y el nombre de la regla Symantec equivalente, siempre que la regla DG siguiera disparando.
5. La acción esperada por destino se calcula así:
   - **Symantec:** detection AND group rule (incluida la universal ASML Users), con la severidad más alta y luego las response rules.
   - **DG:** regla de control con el eo más bajo que consume los tags, incluidas las catch-all.

## Antes de empezar: dos tests que deciden cómo leer el resto

| Test | Si ARC muestra… | Conclusión |
|---|---|---|
| `CONTROL__neutral_content_noincident.txt` a cualquier dominio | Sin incidente | Bien |
| | Tag `asml_ssp_qmd_high` / Block QMD | **Confirmado:** `asml_cl_r_ssp_qmd_high_2` tiene un `SET` colgado de un OR y es true para cualquier fichero. Bloquearía todas las subidas |
| `ENP-IT-IT_Findings-1.2-Monitor__it_findings_info_monitor.txt` a public | Incidente IT Findings | Los contadores funcionan |
| | Sin incidente | **Confirmado:** en las 36 reglas con contador, el contador se compara antes de incrementarlo y no disparan (lista en la hoja "Riesgos de evaluación") |

Por eso el plan tiene dos columnas DG:
- **"diseño":** lo que pretendía quien escribió la regla.
- **"evaluación literal":** lo que pasaría si DG evalúa en orden y el SET devuelve true.

## Procedimiento

1. Copia `data_samples/` al VDI RHEL de pruebas (agente con el bundle Linux).
2. Usa un usuario estándar: no VIP, no LFT key user, no leaver.
3. Sube cada archivo por navegador al dominio indicado en el plan (hoja "Plan de pruebas").
   - Destinos base: public, cloud, customer, trusted, LFT y un dominio sin categoría.
   - Los dominios candidatos de cada categoría están en "Destinos de prueba".
   - Si usas otro dominio, cámbialo en la columna "Dominio de prueba".
4. Impresión: imprime cada archivo en una impresora **fuera** de `dlp-printerwhitelist` (DG debería bloquear siempre) y otra vez en la impresora de la whitelist (no debería bloquear; esto valida el bug `SET`/`LIKE` de DLP6011).
5. Exporta los incidentes de ARC del periodo de pruebas (CSV o XLSX) y ejecuta:
   ```
   python verify_arc.py --plan ASML_DLP_TestPlan.xlsx --arc export_arc.csv -o resultado.xlsx
   ```
   Si no detecta las columnas: `--col-file "Source File Name" --col-rule "Rule Name" --col-dest "Destination URL"`.
6. Lee el resultado:
   - **PASS:** DG hace lo que está configurado.
   - **PASS (literal):** confirma el defecto de orden o de SET.
   - **FAIL:** DG hace otra cosa.
   - **SIN EVENTO:** prueba no ejecutada, o regla que no dispara.

   La columna **"Gap vs Symantec"** marca dónde la configuración DG difiere de Symantec, aunque el test sea PASS.

## Diferencias ya conocidas que el plan pondrá de manifiesto

En el plan base (834 pruebas archivo × destino, sin contar impresión), 583 coinciden con Symantec. Las principales diferencias:

| Symantec | DG | Pruebas | Causa (ver cross-check v2) |
|---|---|---|---|
| Block | User Decision | 43 | Prompts `Block_severity_MEDIUM` y Export Control con botón Allow |
| User Decision / Monitor / Block | Sin acción | 96 | Tags no producidos o no consumidos: Customer Surveys, CAL, GMF CSR, Korean PII, TPD Low/Info |
| Block | Monitor | 23 | KeePass, Rabobank, Cymer en competitor, Team Center |
| Monitor | User Decision / Block | 52 | Catch-all User Decision, tiers Export Control/ZEISS, TPD |
| Sin incidente | Monitor | 18 | DG monitoriza donde Symantec exigía una group rule de identidad (p. ej. BRION) |

## Limitaciones

- No se reproducen las condiciones de identidad (Leavers, VIP, grupos AD, LFT key users). Los tests asumen un usuario estándar.
- La extracción de texto se asume equivalente a la del agente. Los `.docx`, `.xlsx`, `.pptx` y `.pdf` son documentos reales con el texto en el cuerpo.
- Los `.kdb`, `.awoai`, `.aw0file` y `.dat` son texto con la extensión requerida: las reglas DG de esos casos dependen de la extensión o del nombre.
- Los dominios candidatos salen de las listas DG; comprueba que permiten subir ficheros, o usa otro de la misma lista.
