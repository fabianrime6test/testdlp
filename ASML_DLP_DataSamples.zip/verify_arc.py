#!/usr/bin/env python3
"""
Cruza el export de incidentes de ARC con ASML_DLP_TestPlan.xlsx y marca PASS/FAIL.

Uso:
  python verify_arc.py --plan ASML_DLP_TestPlan.xlsx --arc export_arc.csv -o resultado.xlsx
  (acepta .csv o .xlsx; si la detección automática de columnas falla, indícalas:)
  python verify_arc.py --plan ... --arc ... --col-file "Source File Name" --col-rule "Rule Name" --col-dest "Destination URL"

Lógica:
  - Une por nombre de fichero (basename) y por dominio (el de la columna "Dominio de prueba"
    del plan; si subiste a otro dominio, edítalo en el plan antes de ejecutar).
  - Acción observada = acción de la regla de control DG que aparece en ARC (hoja "Reglas DG").
  - PASS              = observada == "Acción DG esperada (diseño)"
  - PASS (literal)    = observada == "Acción DG esperada (evaluación literal)"  -> confirma defecto de orden/SET
  - FAIL              = ARC muestra una acción distinta de la esperada (o incidente donde no se esperaba)
  - SIN EVENTO        = se esperaba acción y no hay evento en ARC para ese fichero+dominio (prueba no ejecutada
                        o regla que no dispara: revisar a mano; ver columna "Riesgo / nota")
  - Gap vs Symantec se mantiene del plan.
"""
import argparse, csv, os, re, sys
import openpyxl

STRENGTH = {'Sin incidente': 0, 'Sin acción (sin regla de control)': 0, 'Monitor': 1, 'Notify': 2, 'User Decision': 3, 'Block': 4}

def load_table(path):
    if path.lower().endswith(('.xlsx', '.xlsm')):
        ws = openpyxl.load_workbook(path, read_only=True, data_only=True).active
        rows = list(ws.iter_rows(values_only=True))
        h = [str(x or '').strip() for x in rows[0]]
        return h, [dict(zip(h, r)) for r in rows[1:]]
    with open(path, newline='', encoding='utf-8-sig', errors='replace') as f:
        sample = f.read(4096); f.seek(0)
        dialect = csv.Sniffer().sniff(sample, delimiters=',;\t|')
        rd = csv.DictReader(f, dialect=dialect)
        return rd.fieldnames, list(rd)

def guess(cols, user, keys):
    if user:
        if user not in cols: sys.exit(f'Columna "{user}" no existe en el export. Columnas: {cols}')
        return user
    low = {c: c.lower() for c in cols}
    for k in keys:
        for c, l in low.items():
            if re.search(k, l): return c
    return None

def base(p):
    p = str(p or '').strip().replace('\\', '/')
    return p.rsplit('/', 1)[-1].lower()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--plan', required=True); ap.add_argument('--arc', required=True)
    ap.add_argument('-o', '--output', default='resultado_pruebas_DLP.xlsx')
    ap.add_argument('--col-file'); ap.add_argument('--col-rule'); ap.add_argument('--col-dest')
    a = ap.parse_args()

    cols, arc = load_table(a.arc)
    cf = guess(cols, a.col_file, [r'source.*file.*name', r'file.?name', r'source.*file', r'\bfile\b', r'path'])
    cr = guess(cols, a.col_rule, [r'rule.?name', r'\brule\b'])
    cd = guess(cols, a.col_dest, [r'url', r'domain', r'dest.*host', r'destination', r'\bdest'])
    print(f'Columnas usadas -> fichero: {cf} | regla: {cr} | destino: {cd}')
    if not cf or not cr: sys.exit('No se detectaron las columnas de fichero/regla. Usa --col-file / --col-rule.')

    wb = openpyxl.load_workbook(a.plan)
    rules = {str(r[0]).strip().lower(): r[1] for r in wb['Reglas DG'].iter_rows(min_row=2, values_only=True) if r[0]}
    idx = {}
    for r in arc:
        idx.setdefault(base(r.get(cf)), []).append(r)

    ws = wb['Plan de pruebas']
    H = [c.value for c in ws[1]]
    col = {h: i + 1 for i, h in enumerate(H)}
    stats = {}
    for row in range(2, ws.max_row + 1):
        f = base(ws.cell(row, col['Archivo']).value)
        cat = ws.cell(row, col['Destino (categoría)']).value
        doms = [d.strip().lower() for d in str(ws.cell(row, col['Dominio de prueba']).value or '').split(',') if d.strip()]
        exp = ws.cell(row, col['Acción DG esperada (diseño)']).value
        lit = ws.cell(row, col['Acción DG esperada (evaluación literal)']).value
        cands = idx.get(f, [])
        if cat == 'PRINT':
            cands = [r for r in cands if 'print' in str(r.get(cr, '')).lower() or 'dlp6011' in str(r.get(cr, '')).lower()]
        elif cd:
            cands = [r for r in cands if any(d in str(r.get(cd, '')).lower() for d in doms)]
        obs_rules = sorted({str(r.get(cr, '')).strip() for r in cands if r.get(cr)})
        acts = [rules.get(x.lower(), 'Regla no reconocida') for x in obs_rules]
        known = [x for x in acts if x in STRENGTH]
        obs = max(known, key=STRENGTH.get) if known else ('Sin incidente' if not acts else acts[0])
        exp_n = 'Sin incidente' if str(exp).startswith('Sin acción') else exp
        lit_n = 'Sin incidente' if str(lit).startswith('Sin acción') else lit
        res = 'PASS' if obs == exp_n else ('PASS (literal)' if obs == lit_n else 'FAIL')
        if not cands and exp_n != 'Sin incidente':
            res = 'SIN EVENTO (¿no ejecutado o no detectado?)' if lit_n != 'Sin incidente' else 'PASS (literal)'
        ws.cell(row, col['ARC: regla observada']).value = '; '.join(obs_rules)
        ws.cell(row, col['ARC: acción observada']).value = obs
        ws.cell(row, col['Resultado']).value = res
        color = {'PASS': 'D5F5E3', 'PASS (literal)': 'FAD7A0', 'FAIL': 'F5B7B1'}.get(res, 'E5E7E9')
        ws.cell(row, col['Resultado']).fill = openpyxl.styles.PatternFill('solid', start_color=color, fgColor=color)
        stats[res] = stats.get(res, 0) + 1
    s = wb.create_sheet('Resumen resultado', 0)
    s.append(['Resultado', 'Pruebas'])
    for k, v in sorted(stats.items()): s.append([k, v])
    wb.save(a.output)
    print('Resultado:', stats, '->', a.output)

if __name__ == '__main__':
    main()
