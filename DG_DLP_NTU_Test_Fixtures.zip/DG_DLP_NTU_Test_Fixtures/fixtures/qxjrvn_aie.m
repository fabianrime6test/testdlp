Copyright
ASML Netherlands B.V.
All rights reserved
SWCHG20260924ABCD
