# DG DLP NTU test fixtures

This pack contains generated, synthetic fixtures mapped to the source detection rules in the accompanying Excel test plan. The fixture names are deliberately low-collision and are the primary correlation key with the upload time and the event in DGMC/ARC.

## Before testing

1. Use a dedicated test repository/location, never a production repository or a public GitHub repository.
2. Confirm the exact GitHub and internal-portal URLs are in scope for the current DG rules.
3. In the Excel plan, complete the target DG rule, expected action, and target URL fields before executing a test.
4. Upload one fixture at a time from the RHEL 9 VDI and record the UTC time, filename, and event ID.

## Safe preflight script

Run this first on the VDI:

    bash run_minimal_test.sh --check

It only checks whether Bash/basic utilities/Firefox are available. It does not open a browser, upload anything, query DG, or change the system.

Use these commands to navigate the pack:

    bash run_minimal_test.sh --list
    bash run_minimal_test.sh --show DET-001

## Fixture conventions

- Generated fixtures contain only the minimum source literals or regex vectors needed for the test. They do not contain generic headings or test IDs in their content.
- Some fixture formats are extension/name tests only. The Excel plan marks these as requiring validation of the final DG file-identification behaviour.
- No fixture is supplied for the cases in `to_validate/README.md`; they need a target-rule definition, a valid proprietary sample, approved test data, or additional channel/identity context.
