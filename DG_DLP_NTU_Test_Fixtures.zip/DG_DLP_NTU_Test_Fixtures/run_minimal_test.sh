#!/usr/bin/env bash
set -u

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MANIFEST="$SCRIPT_DIR/fixture_manifest.psv"
FIXTURE_DIR="$SCRIPT_DIR/fixtures"
MODE="${1:---check}"

usage() {
  echo "Usage: bash run_minimal_test.sh --check|--list|--show <DET-ID>"
}

if [[ ! -r "$MANIFEST" || ! -d "$FIXTURE_DIR" ]]; then
  echo "FAIL: fixture manifest or fixture directory is missing."
  exit 2
fi

case "$MODE" in
  --check)
    echo "PASS: Bash script execution works."
    for CMD in awk find date; do
      if command -v "$CMD" >/dev/null 2>&1; then
        echo "PASS: $CMD available."
      else
        echo "WARN: $CMD not found."
      fi
    done
    if command -v firefox >/dev/null 2>&1; then
      echo "PASS: Firefox available."
    else
      echo "WARN: Firefox not found in PATH."
    fi
    COUNT=$(find "$FIXTURE_DIR" -maxdepth 1 -type f | wc -l | tr -d ' ')
    echo "Fixtures found: $COUNT"
    echo "No browser, network, or policy action was performed."
    ;;
  --list)
    awk -F'|' 'NR==1 {print; next} {print $1 "|" $2 "|" $7 "|" $8}' "$MANIFEST"
    ;;
  --show)
    if [[ $# -lt 2 ]]; then
      usage
      exit 2
    fi
    awk -F'|' -v id="$2" 'NR==1 || $1==id {print}' "$MANIFEST"
    ;;
  --help|-h)
    usage
    ;;
  *)
    usage
    exit 2
    ;;
esac
