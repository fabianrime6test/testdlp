# Folder where files will be created
$OutputFolder = "C:\TestFiles"
New-Item -ItemType Directory -Force -Path $OutputFolder | Out-Null

# List of filenames
$filenames = @(
"D00_report.txt",
"backup_D00_2024.log",
"notes_D100_final.csv",
"temp_D200file.dat",
"archive_D300_v2.bin",
"D400-summary.docx",
"myfolder_D400_testfile.pdf",
"fmsr_ABCDEFGHIJKLM.txt",
"fmsr.1234567890123.dat",
"fmsr-zzzzzzzzzzzzz.bin",
"fmsr_0000report.csv",
"fmsr_0000_testfile.log",
"GSA_AB_1234_test.txt",
"GSA.XY.9876.file.dat",
"GSA-12-3456-report.bin",
"GSA-0alpha.txt",
"GSA-0_testfile.log",
"VOLU.123.ABCDE.txt",
"VOLU.aaa.12345.dat",
"VOLU_report.txt",
"VOLUfile.data",
"backup_VOLU_2024.log",
"REQS.111.AAAAA.txt",
"REQS.abc.12345.dat",
"REQS_report.txt",
"REQSfile.data",
"notes_REQS_2024.log",
"TOOL.999.QWERT.txt",
"TOOL.abc.54321.dat",
"TOOL_config.ini",
"TOOLfile.data",
"backup_TOOL_2024.log",
"ANCI.123.AAAAA.txt",
"ANCI.abc.12345.dat",
"ANCI_report.txt",
"ANCIfile.data",
"folder_ANCI_2024.log",
"SERV_config.txt",
"mySERVfile.dat",
"backup_SERV_2024.log",
"report_4022.txt",
"file4022version.dat",
"backup_4022_log.bin",
"4035_ABC_12345.txt",
"4035.DEF.67890.dat",
"4035-XYZ-54321.log",
"4035_QWE_99999.csv",
"8122_ABC_12345.txt",
"8122.DEF.67890.dat",
"8122-XYZ-54321.log",
"8122_QWE_99999.csv",
"4022file.txt",
"my_4022_document.log",
"4022ABC_110-test.txt",
"4022XYZ-110-report.dat",
"folder_4022_backup.csv"
)

# Create each file with test content
foreach ($file in $filenames) {
    $path = Join-Path $OutputFolder $file
    $content = "Test content for file: $file"
    New-Item -ItemType File -Path $path -Force | Out-Null
    Set-Content -Path $path -Value $content
}

Write-Host "All test files created in $OutputFolder"